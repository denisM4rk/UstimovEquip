﻿using HardwareApp.AppFiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HardwareApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationPage.xaml
    /// </summary>
    public partial class AuthorizationPage : Page
    {
        public AuthorizationPage()
        {
            InitializeComponent();
        }

        private void BtnAuthorization_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var employeeObj = DbConnect.entObj.Employee.FirstOrDefault(x => x.Login == TxbLogin.Text && x.Password == PsbPassword.Password);
                if (employeeObj == null)
                {
                    MessageBox.Show("Такой сотрудник не найден.",
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Information);

                    AuthorizationHistory history = new AuthorizationHistory()
                    {
                        DateAndTime = DateTime.Now,
                        Status = "Не успешно",
                        IdEmployee = null
                    };

                    DbConnect.entObj.AuthorizationHistory.Add(history);
                    DbConnect.entObj.SaveChanges();
                }
                else
                {
                    switch (employeeObj.IdRole)
                    {
                        case 1:
                            MessageBox.Show("Здравствуйте, сотрудник - " + employeeObj.FullName,
                                            "Уведомление",
                                            MessageBoxButton.OK,
                                            MessageBoxImage.Information);

                            int id = employeeObj.Id;
                            FrameApp.frmObj.Navigate(new EmployeePage(id));
                        break;

                        case 2:
                            MessageBox.Show("Здравствуйте, руководитель - " + employeeObj.FullName,
                                            "Уведомление",
                                            MessageBoxButton.OK,
                                            MessageBoxImage.Information);
                            
                            int id2 = employeeObj.Id;
                            FrameApp.frmObj.Navigate(new SupervisorPage(id2));
                        break;

                        case 3:
                            MessageBox.Show("Здравствуйте, администратор - " + employeeObj.FullName,
                                            "Уведомление",
                                            MessageBoxButton.OK,
                                            MessageBoxImage.Information);

                            FrameApp.frmObj.Navigate(new AdministratorPage());
                        break;
                    }

                    AuthorizationHistory history = new AuthorizationHistory()
                    {
                        DateAndTime = DateTime.Now,
                        Status = "Успешно",
                        IdEmployee = employeeObj.Id
                    };
            
                    DbConnect.entObj.AuthorizationHistory.Add(history);
                    DbConnect.entObj.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Критический сбой в работе приложения: " + ex.Message.ToString(),
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
            }
        }
    }
}

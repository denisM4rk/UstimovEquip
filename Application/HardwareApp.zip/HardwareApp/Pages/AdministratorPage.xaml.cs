﻿using HardwareApp.AppFiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HardwareApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdministratorPage.xaml
    /// </summary>
    public partial class AdministratorPage : Page
    {
        public string Photo { get; set; }

        public AdministratorPage()
        {
            InitializeComponent();

            GridEquip.ItemsSource = DbConnect.entObj.Equipment.ToList();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new AuthorizationPage());
        }

        private void BtnHistory_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new HistoryPage());
        }

        private void BtnStatus_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new HardwareStatusPage());
        }
    }
}

﻿using HardwareApp.AppFiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HardwareApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для HardwareStatusPage.xaml
    /// </summary>
    public partial class HardwareStatusPage : Page
    {
        public HardwareStatusPage()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            var equipmentObj = DbConnect.entObj.Equipment.FirstOrDefault(x => x.SerialNumber == TxbSerial.Text);
            if (equipmentObj == null)
            {
                MessageBox.Show("Такого оборудования не найдено",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
            else
            {
                switch (equipmentObj.RoomNumber)
                {
                    case 1:
                        StackRoomOne.Background = new SolidColorBrush(Colors.LightGreen);
                        StackRoomTwo.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomThree.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFour.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFive.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomSix.Background = new SolidColorBrush(Colors.LightBlue);
                        break;
                    case 2:
                        StackRoomTwo.Background = new SolidColorBrush(Colors.LightGreen);
                        StackRoomOne.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomThree.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFour.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFive.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomSix.Background = new SolidColorBrush(Colors.LightBlue);
                        break;
                    case 3:
                        StackRoomThree.Background = new SolidColorBrush(Colors.LightGreen);
                        StackRoomTwo.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomOne.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFour.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFive.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomSix.Background = new SolidColorBrush(Colors.LightBlue);
                        break;
                    case 4:
                        StackRoomFour.Background = new SolidColorBrush(Colors.LightGreen);
                        StackRoomTwo.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomThree.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomOne.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFive.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomSix.Background = new SolidColorBrush(Colors.LightBlue);
                        break;
                    case 5:
                        StackRoomFive.Background = new SolidColorBrush(Colors.LightGreen);
                        StackRoomTwo.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomThree.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFour.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomOne.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomSix.Background = new SolidColorBrush(Colors.LightBlue);
                        break;
                    case 6:
                        StackRoomSix.Background = new SolidColorBrush(Colors.LightGreen);
                        StackRoomTwo.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomThree.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFour.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomFive.Background = new SolidColorBrush(Colors.LightBlue);
                        StackRoomOne.Background = new SolidColorBrush(Colors.LightBlue);
                        break;
                }

                Random rnd = new Random();
                int value = rnd.Next(0, 2);
                StatusTxb.Text = Convert.ToString(value);

                if (value == 0)
                {
                    NotWorkCross.Stroke = new SolidColorBrush(Colors.Red);
                    WorkCross.Stroke = new SolidColorBrush(Colors.Transparent);
                }
                else
                {
                    NotWorkCross.Stroke = new SolidColorBrush(Colors.Transparent);
                    WorkCross.Stroke = new SolidColorBrush(Colors.Green);
                }
            }
        }
    }
}
